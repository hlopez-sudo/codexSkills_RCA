Revenue Cloud Skills — Headless MCP Only

Contains the current live Quote, Managing Asset Lifecycle and Managing Revenue
Conversion skills, including references, API mappings, dependency metadata and
helper scripts. Extract and copy the three skill directories into your Codex
skills location, preserving their internal structure. Connect and authenticate
Salesforce Headless MCP in the destination environment.

The mapped Salesforce transaction and lifecycle actions use Headless direct APIs.
The Quote skill retains its documented local REST fallback for proposal PDF
generation/download; this export does not change the installed skill behavior.

MANIFEST.json records SHA-256 hashes of the exported skill files.
Caches and Python bytecode are excluded. Test coverage and documentation-only
routes remain recorded in each skill's supporting references.
