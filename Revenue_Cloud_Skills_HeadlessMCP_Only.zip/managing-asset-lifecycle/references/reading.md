# Read asset inventory and usage

For account asset views, use the inventory query in [SKILL.md](../SKILL.md), include **Monetary commitments in asset listings**, then follow **Default: raw journal entries** below. An explicit inventory-only request skips journals, but still includes monetary commitment amounts. Reuse resolved account/asset IDs and verified schema; do not add routine metadata, broad entitlement or rate discovery.

## Monetary commitments in asset listings

Include the applicable commitment amount and currency for every monetary-commit asset in the inventory, without requiring a separate request for financial details. Reuse a current verified live-asset entitlement when available; a draft quote's grant is not the live asset's commitment. Use known product/usage-model context to identify candidates. When that classification is unavailable, the scoped currency Commit query below identifies the matching assets without a product-schema lookup. Product or asset names alone do not establish an amount.

Use Headless `dispatch_readonly`, `GET /services/data/v68.0/query`, `userType: business`, with this SOQL in `queryParams.q`. Batch the selected candidate asset IDs into one query; when classification is unknown, use the selected inventory IDs. These fields are already documented and verified in this skill; do not rediscover or describe them.

```sql
SELECT Id, AssetId, UsageResourceId, UsageResource.Name,
       UsageResource.Category, EntitlementUomId, EntitlementUom.Name,
       GrantType, EntitlementQuantity, ActionType,
       EffectiveStartDateTime, EffectiveEndDateTime
FROM TransactionUsageEntitlement
WHERE AssetId IN (<resolved asset ids>)
  AND GrantType = 'Commit'
  AND UsageResource.Category = 'Currency'
```

Use `EntitlementQuantity` from the applicable live currency Commit entitlement and its verified currency denomination/unit. Select by the displayed asset term and requested as-of instant (default: now), respecting effective dates and known supersession semantics. Do not select the newest row or largest amount blindly, sum historical/replaced commitments, or multiply the entitlement by CurrentQuantity. A future or expired term must be labeled with its dates; do not present its amount as a current active commitment. Keep distinct resources/currencies and periods separate. If overlapping rows cannot be resolved from the returned data and known semantics, show the dated candidates and mark a single commitment amount as unresolved.

Present `Asset | Current quantity | Term | Commitment`, with the amount and currency to two decimals, for example `USD 500,000.00`. Preserve nulls; a missing entitlement, failed query or unknown currency is not zero. For a known monetary-commit asset with no verified amount, show `Unavailable` and briefly explain why. For non-monetary assets, use `—`; do not infer non-monetary classification merely from a failed or empty lookup. If none of the selected assets has a monetary commitment, omit the column.

Run this scoped read concurrently with independent journal preview queries after inventory is resolved. This is an inventory amount, not remaining balance, consumption or billed charges: do not subtract journals or fetch allowance grants, rated summaries or rates. Existing relationships may be reused; resolve only a specific missing binding when a monetary-commit asset cannot be matched directly. No general entitlement audit or amendment/renewal preflight is added.

## Default: raw journal entries

1. Use the requested period, or each asset's current lifecycle term through the query's as-of instant. Filter on ActivityDate using full ISO DateTimes and disclose the period. Exclude future activity. If the asset has not started, its term has ended, or the term cannot be established, state that briefly rather than choosing an invented current window.
2. Read directly associated journals through ReferenceRecordId with UsageType = UsageManagement. Reuse known Anchor/binding mappings where applicable. When a Commit/Pack has no direct journals and its attribution is unresolved, query only the relevant relationship needed to locate its usage. A shared account or product name does not prove attribution. UsageCmtAssetRelatedObj supplies the commitment asset, related object and effective window; account/contract bindings may need a narrower asset/resource mapping. Show shared Anchor entries once and identify the association, without allocating the same entries to multiple commitments.
3. Return up to five latest entries per asset by default, preserving the saved Quantity, sign, resource and unit. Disclose the limit; retrieve all pages only when all entries are requested. After the inventory is available, run independent bounded journal queries concurrently, using the same as-of instant and preserving each asset's period and preview limit. Batch compatible reads using verified relationships when available; do not rediscover them for each request.
4. Do not query, filter, group, analyze or report journal Status for this raw-entry view. Beyond the scoped monetary commitment lookup above, do not query grants, balances, rating jobs or catalog rates, analyze user activity or usage trends, compute totals/percentages/forecasts, or generate recommendations. These records are raw journal quantities, not proof of billed charges or commitment drawdown.
5. Distinguish no matching entries from an unavailable query or unresolved attribution. Preserve nulls rather than converting them to zero. Do not silently omit an asset when its usage read fails; return the available inventory and identify the missing usage briefly.

Run the following bounded query through Headless `dispatch_readonly`, `GET /services/data/v68.0/query`, with SOQL in `queryParams.q` and `userType: business`. Its raw-journal fields were previously live-tested; the v68.0 Headless query transport was verified November 12. Substitute the selected asset and reporting bounds:

```sql
SELECT Id, Name, ReferenceRecordId, ActivityDate,
       UsageResourceId, UsageResource.Name, Quantity,
       QuantityUnitOfMeasureId, QuantityUnitOfMeasure.Name
FROM TransactionJournal
WHERE ReferenceRecordId = '<asset id>'
  AND UsageType = 'UsageManagement'
  AND ActivityDate >= <period start ISO DateTime>
  AND ActivityDate <= <as-of ISO DateTime>
ORDER BY ActivityDate DESC, Id DESC
LIMIT 5
```

For a combined query, use resolved IDs and per-asset bounds where terms differ. A single global LIMIT must not silently remove another asset's entries. Counts returned by a limited query describe the returned rows, not necessarily every matching entry; do not add a count query just for presentation.

Present the asset inventory with its monetary Commitment column when applicable, then `Asset | Activity date | Resource | Quantity | Unit`. Use compact per-asset sections when clearer. Apply the asset-name, internal-ID and optional-link rules from SKILL.md. Keep different resources and units separate, including currency versus tokens. A USD journal quantity is a recorded usage amount, not the asset's commitment. Display money to two decimals without deriving new amounts.

Include no status columns, counts, labels or commentary, and no recommendations or suggested action menu. Finish with exactly:

> Given these assets and their recorded usage, how would you like to proceed?

Use this fixed closing question without additional data reads or analysis. Honor an explicit request to omit follow-up questions. Asset viewing is read-only: do not ingest usage, run orchestration/rating, repair records or start an amendment. Stop after reporting; the sections below apply only when the user separately requests deeper information.

## Explicit requests for balances, rates or analysis

Do not assume Asset has ContractId. Resolve contract/order/asset relationships through verified fields. Keep nulls distinct from zeros, and do not assume a commitment asset always has a zero price.

## Usage questions need a period and attribution

Select the requested as-of date or term. State the reporting period. Read entitlements with identity, resource/unit IDs and effective start/end fields so multiple historical/future rows can be distinguished:

```sql
SELECT Id, AssetId, UsageResourceId, UsageResource.Name,
       UsageResource.Category, EntitlementUomId, EntitlementUom.Name,
       GrantType, EntitlementQuantity, ActionType,
       EffectiveStartDateTime, EffectiveEndDateTime
FROM TransactionUsageEntitlement WHERE AssetId IN (<resolved ids>)
```

These entitlement fields were verified through Headless on November 12, 2026. Reuse the known schema; validate only unfamiliar or changed fields. Do not put non-aggregate aliases on a normal SOQL field list.

Choose the applicable entitlement for the asset/resource/unit/grant type and reporting period, using verified validity and supersession rules. Latest CreatedDate or latest non-Renewal row alone is not sufficient: it might be future dated, cancelled, outside the current term or superseded. Never sum all historical Commit rows. If multiple overlapping rows remain ambiguous, show them with their dates and withhold a single balance.

Aggregate journals for the **same period and attribution scope**, with explicit aliases for potentially duplicate Name fields:

```sql
SELECT ReferenceRecordId, UsageResourceId,
       UsageResource.Name resourceName,
       UsageResource.Category resourceCategory,
       QuantityUnitOfMeasureId,
       QuantityUnitOfMeasure.Name unitName,
       SUM(Quantity) consumed, COUNT(Id) journalCount,
       MIN(ActivityDate) firstUsage, MAX(ActivityDate) lastUsage
FROM TransactionJournal
WHERE ReferenceRecordId IN (<resolved attribution ids>)
  AND UsageType = 'UsageManagement'
  AND ActivityDate >= <period start>
  AND ActivityDate < <exclusive period end>
GROUP BY ReferenceRecordId, UsageResourceId, UsageResource.Name,
         UsageResource.Category, QuantityUnitOfMeasureId,
         QuantityUnitOfMeasure.Name
```

Use the actual ActivityDate field type when forming date literals. Validate journal status/reversal semantics and filter or net them according to the org's model; do not call every recorded row billable consumption without evidence. Aggregate pagination/row limits must be handled or the totals are incomplete. A failed query is not zero consumption.

## Remaining amount

`remaining = applicable granted amount - consumed in that entitlement's period` only when resource identity, unit, denomination and subscription/wallet attribution match. `NetQuantity` and `TransactionQuantity` are not assumed remaining-balance fields. Do not subtract lifetime usage from a current-term commitment, sum unrelated wallets or convert tokens to USD with an invented rate.

Usage may be recorded against a related Anchor asset. Establish that relationship from actual transaction/binding records before allocating its journals to a commitment. Reading all account assets can find candidates, but sharing an account or product name is not proof of a shared wallet. If attribution cannot be established, show consumption and commitment separately and mark remaining unavailable.

Keep Currency, Token and Usage categories and input/output units separate. A Currency resource's Quantity can represent money; confirm its denomination. Zero-valued allowances may be summarized with their count and units if no consumption is hidden. Nonzero or consumed rows remain visible.

## Rate/policy details and history

Use Headless `dispatch_readonly`, `GET /services/data/v68.0/asset-management/assets/{assetId}/usage-details`, with required `effectiveDate` in `queryParams`. For established binding-target grants/rates/policies, use `GET /services/data/v68.0/revenue/usage-management/binding-objects/{bindingObjectId}/actions/usage-details` with required `effectiveDate` in yyyy-MM-dd format. Resolve actual attribution first, as above. These documented routes are in the [API mapping](mcp-routing.md); neither was newly live-tested November 12. Inspect only the requested assets/bindings. Do not use quote pricing as the live asset's pricing or substitute these detail APIs for raw journals.

For an explicit request for journal history, use its requested period and pagination. The default asset view already includes a bounded raw-entry preview. For requested aggregate analysis, disclose any detail cap and keep totals from the complete aggregate, not the displayed sample. Read AssetAction history when a renewal explanation or explicit history request needs it; verify CategoryEnum/action meaning instead of treating an API Type as a commercial label.

## Present

For default asset views, use the inventory with monetary commitment amounts and the raw-entry presentation above, then stop. The following presentation is for separately requested deeper analysis. Display Asset.Name in the Asset column and follow the record-details and optional-link rules in [SKILL.md](../SKILL.md). Keep IDs internal unless explicitly requested. Duplicate names remain separate rows. For usage, add `Asset | Resource | Unit | Period | Granted | Consumed | Remaining`, and the journal count/date span. Missing data is `—`. Use two-decimal numeric display with exact values retained internally.

Factual usage and elapsed-term arithmetic can inform a discussion. Do not turn sparse demo records into a pace judgement or recommend a new commitment unless the user asks for a reasoned forecast and the available evidence supports it. The original six-journal/90-day threshold is not a platform rule or a universally sufficient forecast sample.
