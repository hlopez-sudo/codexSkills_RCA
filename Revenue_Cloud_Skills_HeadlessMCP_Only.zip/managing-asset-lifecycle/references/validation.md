# Validation evidence and limits

Reviewed against the repo's release 264 documentation. Historical sections retain their original transport labels; current routes are in [API mapping](mcp-routing.md). October 22, 2026 tests below occurred October 23 UTC; the November 12 direct Headless test is recorded separately.

## Live-tested behavior

| Operation | Observed result |
|---|---|
| Asset inventory | One scoped SOQL query returned all three Pied Piper assets. CurrentQuantity was 500, 500 and 1; Quantity and Status were null. |
| Batch amendment creation | One amendAssets call with three IDs and quantityChange 0 created quote 00000042, effective January 1, 2027. API call: 15.768 seconds; first read-back: 1.242 seconds. |
| Initial calculation | The first read showed TaxCalculationWaiting; one narrow follow-up read showed CompletedWithTax. No standalone reprice was needed. |
| Nonzero delta while No Change | updateLines returned a nested business validation error despite HTTP 201. All three quantities remained unchanged. |
| Generic QuoteAction PATCH | Failed with FUNCTIONALITY_NOT_ENABLED: update is not supported for QuoteAction. Describe's updateable flag did not establish this route's support. |
| Combined REST graph | Headless Place Sales Transaction PATCHed the parent, three existing QuoteActions to Amend, then three existing lines to Quantity 500. HTTP 201, isSuccess true, empty errorResponse. Mutation call: 5.158 seconds. |
| Final read-back | Same quote/line/action/source IDs; Start 500/500/1, delta 500/500/500, End 1,000/1,000/501. January 1–October 21, 2027 dates preserved. CompletedWithPricing. |

The successful graph used pricingPref System, taxPref Skip, configurationMethod Skip and catalogRatesPref Skip. It required no Apex, second line-edit call or separate reprice. This test establishes the required No Change → Amend prerequisite and the combined REST route.

A separate immediate amendment attempt using an earlier local midnight failed the usage past-date check. Retrying with the current ISO instant succeeded. Explicit business dates must still be honored under the asset time-zone rules, not shifted automatically.

An earlier test recorded quantity-plus-commitment editing through the business Apex executor. That historical result is not evidence that every grant/rate combination has been retested through REST; the runtime instructions now use the successful REST route and do not require Apex.

## Limits of the October review

These are individual observed call durations, not a benchmark or end-to-end latency guarantee. Renewal, cancellation and downstream execution of these amendment quotes were not tested in this review. The quantity-only REST test did not audit all grants, rates or policies; platform grant proration remains possible. The source assets were not amended through order activation.

## Documentation basis

The repo's `docs/salesforce/264/dev-guide/articles/quote_and_order_capture_fields_on_quote_line_item.htm.md` defines StartQuantity as the quantity at the line's start date and EndQuantity as read-only, calculated from StartQuantity plus Quantity. The existing live read-backs returned all three fields. Displaying all three in amendment views and edit confirmations is a user-requested presentation rule; it requires no new mutation API or extra audit.

- [Asset Amendment API](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-amend.html): dedicated amendment creation and Quote-first usage amendments.
- [Asset Renewal API](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-renew.html): renewal inputs and optional standard dates.
- [Asset Cancellation API](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-cancel.html): dedicated cancellation and required inputs.
- [Asset time-zone precision](https://help.salesforce.com/s/articleView?id=ind.qocal_asset_lifecycle_date_time_precision.htm&language=en_US&type=5): stored ASP time zone, common transaction time zone and UTC fallback.
- [Usage selling considerations](https://help.salesforce.com/s/articleView?id=ind.qocal_considerations_usage_selling.htm&language=en_US&type=5): date restrictions, expired-renewal exception and grant behavior.

The repo's postman/docs/transaction-management-apis-reference.md separates dedicated lifecycle creation from Place transaction edits and documents partial header persistence after a later processing failure. Prefer the grounded release 264 Markdown and current tool schemas over older Postman collection versions. Actual support for QuoteAction in the REST graph comes from the live test above, not an inferred generic CRUD capability.

The proposed call ordering, session reuse and conditional reads are workflow optimizations inferred from these API contracts and observed results; they are not Salesforce-mandated performance guarantees. Renewal/cancellation date behavior, nonzero delta at amendment creation and every grant/rate-edit combination have not all been exercised in this review.

## Raw usage in asset views — November 4, 2026

The connected Revenue Cloud SOQL tool returned the salesforce.com account with two assets in one account/asset relationship query. Two scoped journal queries, executed together with a five-entry limit per asset, returned two Engineering entries and three Solutions entries. Each selected ActivityDate, resource, raw Quantity and unit, bounded by that asset's lifecycle start and the as-of instant. No journal Status field, status predicate, aggregate, entitlement query, rating operation or Salesforce write was used.

The returned journal quantities were Engineering USD 58,490 and 73,400; Solutions USD 89,403, 86,943 and 42,000. These values validate direct record retrieval, not billed charges or remaining commitment. The user interrupted the asset response to request skill publication first; no completed user-facing response from that interrupted turn is claimed as a behavioral test.

The repo's release 264 TransactionJournal reference documents ReferenceRecordId, ActivityDate, UsageResourceId, Quantity, QuantityUnitOfMeasureId and UsageType. UsageCmtAssetRelatedObj documents the effective commitment relationship. The default term-to-date window, five-entry preview and neutral follow-up are workflow choices, not API requirements.

Direct association and different lifecycle start dates were live-verified. Shared-Anchor allocation, unavailable reads, all-entry pagination and other optional branches were not newly live-tested for this update. Do not add live mutations or broad tests to an ordinary asset view. Preserve all prior amendment/conversion validation limits.

## Direct Headless lifecycle test — November 12, 2026

Dedicated `POST /services/data/v68.0/connect/revenue-management/assets/actions/amend` created Quote 00000105 (`0Q0bm0000044TdpCAE`) for two Pied Piper assets, effective November 12. The response was HTTP 201 with success true, no errors, an amendmentRecordId and requestId, and null statusUrl. The first read was CompletedWithTax; no polling or repricing was needed.

A single v68.0 Place graph transitioned both existing No Change actions, set Quantity to +250 on both lines and increased the existing USD Commit grants by 100,000. Preferences were System pricing, tax Skip, configuration Skip and catalog Skip. Read-back confirmed:

| Asset | Start | Change | End | Commitment before | Commitment after |
|---|---:|---:|---:|---:|---:|
| GPT Enterprise Monetary Commit for Solutions | 500 | +250 | 750 | USD 500,000 | USD 600,000 |
| GPT Enterprise Monetary Commit for Engineering | 1,000 | +250 | 1,250 | USD 1,000,000 | USD 1,100,000 |

Original end dates, BillTo and all 16 unrelated allowance grant rows were preserved. Quote line NetUnitPrice became null while NetTotalPrice and GrandTotal remained zero; null was retained, not treated as zero. The resulting order matched these saved prices. Commitment amounts were verified separately from priced charges.

Direct standard-action conversion created Order 00000144 (`801bm00003Hq8r0AAB`). Source-line mappings, three quantities, dates and USD Commit grants matched. Status-only Order PATCH returned HTTP 204 and the read-back confirmed Activated and ActivatedDate.

| Mutation | Seconds |
|---|---:|
| Amend creation | 13.029 |
| Combined quantities/commitments | 5.446 |
| Conversion | 5.340 |
| Activation | 3.482 |

Mutation calls totaled 27.297 seconds; full elapsed was 126.755 seconds including verification, analysis and orchestration. These are observations, not a latency guarantee. No revCloud, Apex, CLI, catalog refetch, standalone reprice or discovery calls were needed in the successful sequence. Earlier discovery misses did not prevent direct dispatch.

This run did not test renewal, cancellation, standalone repricing, explicit asset provisioning or rate/tier preservation, and did not separately verify downstream live asset/entitlement updates. It does establish combined amendment quantity/Commit editing and subsequent conversion/activation through Headless. Evidence: project `headless-migration-test-2026-11-12/direct-dispatch-results.json`.

## Direct amendment performance tests — November 12, 2026

The user requested two additional Draft amendment quotes for the existing Pied Piper Engineering and Solutions assets, effective `2026-11-12T00:00:00Z`, with `quantityChange: 0`. Both used one `POST /services/data/v68.0/connect/revenue-management/assets/actions/amend` with `outputRecordType: Quote`, followed by one combined quote header/lines query. Neither test used Salesforce discovery, describe, schema, currency, time-zone, price-book or source-history preflight calls.

Both responses returned HTTP 201, success true, empty errors and an amendmentRecordId. Read-backs confirmed Draft status, both source-asset mappings, November 12 start dates, the existing end dates, and Engineering Start/Change/End 1,000/0/1,000 and Solutions 500/0/500. Initial reads showed pending tax calculation; only the quote header was polled afterward. Both reached CompletedWithTax without repricing or further writes.

| Quote | Creation call (seconds) | First read call (seconds) | First verified read elapsed (seconds) | Completion observed elapsed (seconds) | Header polls |
|---|---:|---:|---:|---:|---:|
| 00000111 | 6.437 | 2.423 | 13.986 | 69.021 | 2 |
| 00000112 | 15.276 | 1.434 | 21.711 | 38.200 | 1 |

Measurements come from the live Headless tool results and local elapsed timers in the November 12 conversation. Elapsed timing starts immediately before each amend call. Quote 00000111's completion-observation interval includes skill-plan research as well as polling and orchestration; Quote 00000112 was a quote-only repeat. These are observations, not pure server-processing durations or a latency guarantee. They support omitting discovery and compatibility preflight and using one initial read plus conditional header polling; they do not establish fixed backend completion time.

These tests created quotes only. They did not test renewal, cancellation, conversion, activation, changed quantities, unknown/mismatched time zones, or incompatible assets. Renewal's direct route remains documentation guidance, not evidence from these amendment tests.

## Monetary commitments in default asset listings — November 12, 2026

The user requested monetary commitment amounts in ordinary asset inventories. The default now reads only applicable currency Commit entitlements and displays amount plus denomination separately from CurrentQuantity and raw journals, including inventory-only requests. Existing documented TransactionUsageEntitlement fields supply the asset, resource, unit, amount, action and effective dates; no schema discovery or lifecycle-creation preflight is introduced.

A scoped read for the two selected Pied Piper assets was attempted with `GrantType = 'Commit'` and `UsageResource.Category = 'Currency'`. The Salesforce MCP transport failed before any query result was returned. The combined filtered query and resulting default presentation were therefore not newly live-verified in this update; no commitment values are asserted from that failed call. The instructions use the previously verified entitlement field mapping, with local skill validation and reference checks. Historical/future overlap, missing currency, non-monetary assets and unresolved binding behavior remain guidance rather than new live tests.
