---
name: managing-asset-lifecycle
description: Read existing Salesforce Revenue Cloud assets, usage and entitlements, or prepare and execute requested amendments, renewals and cancellations. Use for owned subscriptions and asset lifecycle changes. Not for new-sale quote creation, generic revenue settings or unrelated product cancellation.
---

# Managing Asset Lifecycle

Use Headless MCP for all asset reads and lifecycle operations. Dispatch the documented direct APIs without routine discovery/describe calls. Use `dispatch_readonly` with `GET /services/data/v68.0/query` and SOQL in `queryParams.q` for reads; use `dispatch` for writes, with `userType: business`. Reuse verified IDs, source mappings and schemas. The maintained [API mapping](references/mcp-routing.md) records methods, paths, payloads, responses and evidence. Missing discovery results do not establish that a mapped route is unavailable.

For record retrieval and verification, use only connected Salesforce MCP tools. Do not use browser or Computer Use tools, inspect browser tabs, or request browser/computer permissions to retrieve records or verify record links. Once the scoped MCP read is complete, return the requested record details without extra access or URL-verification steps.

## Route by intent

| Request | Procedure |
|---|---|
| View/list account assets | Inventory below, including [monetary commitments](references/reading.md#monetary-commitments-in-asset-listings), then [raw journal entries](references/reading.md#default-raw-journal-entries). Explicit inventory-only requests skip journals, but still include monetary commitment amounts. |
| Usage, balances, journals or current asset rates | [Reading assets and usage](references/reading.md) |
| Create an amendment or cancellation quote | [Amendment and cancellation](references/amend-cancel.md) |
| View or edit an existing amendment quote | [Amendment viewing and editing](references/amendment-edit.md) |
| Renew assets | [Renewal](references/renewal.md) |
| Authentication, unfamiliar schema or ambiguous response | [MCP routing](references/mcp-routing.md) |

For a routine account asset view, read the inventory instructions below and the **Monetary commitments in asset listings** and **Default: raw journal entries** sections of `references/reading.md`. Load routing or schema references only for an actual error or unfamiliar operation; deeper usage sections apply only when requested. [Validation evidence](references/validation.md) distinguishes live tests from documentation guidance; load it when reviewing support or test coverage.

## Direct amendment and renewal creation

When the selected asset IDs and required business inputs are known, the first Salesforce call is the mapped amend or renew POST in **Business inputs and scope** below. Do not call discovery, describe, or schema endpoints first. Do not query currency, price book, AssetStatePeriod time zone or source history to confirm compatibility. Reuse the selection and source context already available; if the selection is missing, resolve only the requested account/assets with a scoped read.

Use one creation call for the selected assets, then one combined quote header/lines read-back. Investigate compatibility or schema only in response to a specific API error, and scope recovery to that error. A requestId alone does not require another call; poll only an actually pending result. The operation references contain the payload and verification details; routing and validation references are not routine preflight.

## Asset inventory

Reuse the account ID from this conversation. If missing, resolve the named account once. Query only that account:

```sql
SELECT Id, Name, Product2Id, Product2.Name, CurrentQuantity,
       LifecycleStartDate, LifecycleEndDate
FROM Asset WHERE AccountId = '<account id>' ORDER BY CreatedDate DESC
```

Present Asset.Name, current quantity and term as record details, using plain-text names by default. Include record links only when explicitly requested and the verified org URL is already available in MCP/session context; otherwise return the details without links. Do not query org domains, login history or other unrelated metadata solely to construct or verify links. Retain IDs internally for follow-up actions; never show full or shortened Asset IDs unless explicitly requested. Keep assets with identical names in separate rows. Use CurrentQuantity for the lifecycle inventory. Null Status or Quantity does not mean zero ownership or failed provisioning. Monetary commitment amounts are part of the default asset inventory. Other hierarchy, usage or financial fields are conditional on the request, not a schema preflight for this query.

For each monetary-commit asset, include a **Commitment** column with the applicable amount and currency, for example `USD 500,000.00`. Read the matching live currency Commit entitlement using [monetary commitments](references/reading.md#monetary-commitments-in-asset-listings); reuse a current verified value when available. Do not infer the amount from CurrentQuantity, asset/product names, prices, quote/order totals or journal quantities. Include it even for inventory-only requests; an explicit request for a narrower set of columns takes precedence.

After retrieving the inventory, include associated raw TransactionJournal quantities and units using [raw journal entries](references/reading.md#default-raw-journal-entries). Default to the current lifecycle term through the as-of instant and show up to five recent entries per asset with the period and preview limit disclosed; honor a requested period or all-entry view. Display only the labels, activity dates, resources, quantities and units needed to understand the entries. Do not fetch or discuss journal status, compute utilization/forecasts, or generate recommendations. The scoped currency Commit entitlement lookup above is the only default entitlement read. Do not fetch other allowances, balances, rated summaries or rates just to enrich this view.

End the asset-and-usage report with “Given these assets and their recorded usage, how would you like to proceed?” unless the user requested no follow-up. Use this fixed closing question without additional queries, analysis of user activity or usage trends, prescriptive recommendations, or suggested actions. This default applies to viewing assets; it adds no usage preflight to amendment creation, line edits, conversion or activation.

When the user refers to assets just listed, reuse that selection. Follow actual hierarchy for bundles; do not discard an Anchor solely because its amount or entitlement is zero. Resolve only material ambiguity. Read-only requests authorize no asset changes.

## Required internal gate before editing an amendment

Before sending changed line or quote-side usage values, inspect the affected lines' existing QuoteAction.Type, reusing a current read-back when available.

- **No Change + an actual requested edit:** set the existing QuoteAction.Type to **Amend** before the line/child updates, in the same Headless Place Sales Transaction REST graph. Follow [amendment editing](references/amendment-edit.md). Do not send changed line or child values before this transition.
- **Amend:** preserve the action; batch supported quantity/date/price and requested grant changes in one Headless Place graph.
- **No effective change:** do not write or transition the action.
- **Renew, Cancel, Add or another action:** preserve it and use its own workflow.

This is a required internal prerequisite to the requested amendment, not a separate user decision. Do not narrate the QuoteAction update in commentary or final responses.

## Business inputs and scope

All writes use Headless `dispatch`, POST. Paths below are relative to `/services/data/v68.0`; assign the REST payload to `dispatch.body` without another nested `body` wrapper.

| Action | API path | REST body |
|---|---|---|
| Amend | `/connect/revenue-management/assets/actions/amend` | `{assetIds, outputRecordType, amendmentStartDate, quantityChange}` |
| Renew | `/connect/revenue-management/assets/actions/renew` | `{assetIds, outputRecordType, renewalStartDate?, renewalEndDate?}` |
| Cancel | `/connect/revenue-management/assets/actions/cancel` | `{assetIds, outputRecordType, cancellationDate}` |
| Edit amendment | `/connect/rev/sales-transaction/actions/place` | Parent Quote PATCH, needed action transitions, then requested line/grant PATCH records with pricing preferences from [amendment editing](references/amendment-edit.md) |

Send outputRecordType explicitly. For usage amendments use Quote: Salesforce documents that direct amendment-to-Order omits required usage records. Convert the amendment quote using the Revenue Conversion skill only when requested.

Batch selected assets into one request; do not call once per asset. Reuse known compatibility information without reconfirming it. For amend and renew, let the API validate compatibility and investigate only a specific returned error; do not add currency, price-book or time-zone preflight reads.

Use full ISO DateTimes. Honor explicit dates/offsets and reuse the asset lifecycle time zone already available in session; when no time zone is available, use UTC for the request rather than adding a preflight read. The viewer's time zone does not override asset semantics. For an unspecified immediate change, use the current instant rather than an earlier local midnight. Preserve saved dates during later edits. Apply the operation-specific date rules in the relevant reference.

An amendment Quantity is a delta from StartQuantity; EndQuantity is derived. A currency Commit, a resource Grant and a seat quantity are distinct. Fetch and edit quote-side grants/rates only when the requested change needs them; use the Quote skill's usage-edit procedure. Do not edit live entitlements or shared catalog rates to change a quote.

Creating a lifecycle quote does not change the live asset. Stop at the requested boundary; use the Revenue Conversion skill for authorized conversion/activation. Never recreate a quote merely because a previous edit failed. Read persisted state before retrying an ambiguous write.

## Verify and report

Check both transport and nested business success, then read the resulting quote header and lines together once. Reuse that read-back for the next request. If processing is pending, poll only the header with bounded backoff; do not repeat line reads or reprice an already completed transaction. Do not audit all grants/rates for a quantity-only edit.

When creating or viewing an amendment, show each in-scope line's **Start Quantity**, **Quantity (change)** and **End Quantity** with the quote reference. After an amendment edit, show all three saved values for each affected line, even when the edit changed a different field. Use a compact table with Asset.Name values for source assets, or meaningful line names when showing quote lines. Apply the record-details and optional-link rules in Asset inventory. Keep repeated asset names in separate rows; do not substitute IDs or ID suffixes for names. Quantity (change) is the saved amendment delta from Start Quantity, not merely the increment in the latest request; show positive/negative signs and retain zero. Do not replace these columns with only a before/after quantity summary. Use the existing scoped read-back, not an additional audit.

Keep action transitions, calculation statuses and resolved internal errors out of user-facing updates. If a requested value was not saved, identify the incomplete change plainly and distinguish saved values from requested targets.

Asset listings always include verified monetary commitment amounts as described above. In lifecycle transaction responses, report a commitment amount only when relevant to the request and verified from the currency Commit grant. Do not substitute quote totals or upfront prices, or query commitments solely to add them to a quantity-edit response. This inventory rule adds no preflight to amend or renew creation. Retain exact values internally; display money/rates to two decimals.
