# Headless API mapping and response contract

Maintenance reference and routing help for missing context or actual errors. Basic workflows identify their direct routes; do not load every reference as preflight.

## Direct execution

Use the known mapped APIs directly through Headless. No revCloud MCP tools are required. Missing discovery results are not evidence that dispatch is unsupported: November 12 direct calls succeeded after unrelated discovery results. Reserve targeted documentation/schema lookup or discovery/description for an unfamiliar operation or actual contract error. Do not switch to unrelated Commerce, Industries CPQ or catalog workflows.

Use `dispatch_readonly` for GET and `dispatch` for POST/PATCH/DELETE, with `userType: business`. Supply relative URLs, `queryParams` separately and REST JSON as `dispatch.body` without another `body` wrapper. The connection handles authentication.

Reuse verified account/asset/quote IDs, source mappings and current values. Refresh only stale, missing or contradicted information, or after a connection change. A fresh scoped target read establishes record context without an identity audit. After reauthentication, refresh the affected target before retrying an ambiguous mutation.

## Maintained API map

Paths below are relative to `/services/data/v68.0`. Former names are migration labels, not callable dependencies. Update the path/version, payload, response, source and dated test scope together when maintaining a route.

| Action / former tool | Method and path | REST request / query | Response / validation |
|---|---|---|---|
| Records / soqlQuery | GET `/query` | `queryParams: {q: "<SOQL>"}` | HTTP 200, `body.records`, `done`, `nextRecordsUrl`; v68.0 live-tested November 12, 2026. |
| Amend / amendAssets | POST `/connect/revenue-management/assets/actions/amend` | `{assetIds, outputRecordType, amendmentStartDate, quantityChange}` | HTTP 201, `success: true`, no `errors`, `amendmentRecordId`; live-tested November 12. |
| Renew / renewAssets | POST `/connect/revenue-management/assets/actions/renew` | `{assetIds, outputRecordType, renewalStartDate?, renewalEndDate?}` | HTTP success, `success: true`, no `errors`, `renewalRecordId`; documented, not tested in this run. |
| Cancel / cancelAssets | POST `/connect/revenue-management/assets/actions/cancel` | `{assetIds, outputRecordType, cancellationDate}` | HTTP success, `success: true`, no `errors`, `cancellationRecordId`; documented, not tested in this run. |
| Amendment edits / updateLines | POST `/connect/rev/sales-transaction/actions/place` | Parent Quote PATCH, required action transitions, requested line/grant PATCH records; preferences and JSON in [editing](amendment-edit.md) | HTTP 201, `isSuccess: true`, empty `errorResponse`, `salesTransactionId`; combined quantity/Commit edits live-tested November 12. |
| Asset grants/rates | GET `/asset-management/assets/{assetId}/usage-details` | Required `effectiveDate`; optional `optionalFields` in queryParams | HTTP 200, usage-detail body; inspect errors. Documented, not newly tested. |
| Binding grants/rates/policies | GET `/revenue/usage-management/binding-objects/{bindingObjectId}/actions/usage-details` | Required `effectiveDate` (yyyy-MM-dd) in queryParams | HTTP 200, binding-detail body; inspect errors. Documented, not newly tested. |

Lifecycle creation bodies may also carry documented contractId, opportunityId and outputRecordId when requested. Use full ISO DateTimes and the operation-specific date rules. Do not replace these REST fields with invocable-action names such as amendAssetIds or an `inputs` wrapper. The mapped Connect lifecycle routes and standard actions have different contracts.

## Reads and response handling

Use scoped SOQL with escaped literals; there are no Apex bind variables. Check child pagination as well as top-level pagination. Follow returned query locators when needed, batch independent reads and chunk large ID lists to fit actual limits. Raw journal entries remain TransactionJournal queries; usage-detail APIs do not replace them.

Check MCP `isError` and plain-text errors before parsing. Prefer `structuredContent`; otherwise parse JSON text. Headless returns `{status_code, body, url}`. Inspect HTTP status and the operation-specific business fields in the table. Do not require Place's `isSuccess` on lifecycle responses, which use `success`. Preserve raw mutation responses and returned IDs before parsing; a client parser error is not grounds to recreate records.

A successful lifecycle response can include requestId with a completed record and null statusUrl. That identifier alone does not require polling. Read the returned record once; poll only an actually pending calculation or returned pending operation with bounded backoff. CompletedWithPricing and CompletedWithTax are completed states.

Do not use direct QuoteAction sObject PATCH, Apex or live entitlement DML as an alternative to the tested Place graph. Keep the action transition internal to the requested edit.

## Recovery and authorization

After timeout, ambiguous error or partial create, read persisted state before retrying. A header can survive later failure. Repair missing requested work without recreating the quote or replaying an additive change. A local schema rejection before dispatch differs from an uncertain server outcome.

Authentication failure requires supported reauthentication, not repeated discovery, credential extraction or a transport switch. Preparing a quote does not authorize activation, approvals, provisioning or shared-catalog edits. Continue only the user's requested stages.

## Evidence and sources

November 12, 2026: dedicated amend created Quote 00000105 for two Pied Piper assets. One Place graph updated quantities and currency Commit grants, preserving 16 allowance rows. Resulting Start/Change/End quantities: 500/+250/750 and 1,000/+250/1,250; commits: USD 600,000 / 1,100,000. Conversion to Order 00000144 preserved the requested values and activation succeeded. [Validation](validation.md) records timings and limits. Project evidence: `headless-migration-test-2026-11-12/direct-dispatch-results.json`.

Canonical repo sources: `postman/docs/transaction-management-apis-reference.md`, `postman/docs/usage-management-apis-reference.md`, and release-264 developer-guide lifecycle input/output snapshots. Prefer those grounded references over old collection examples.

- [Amend](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-amend.html)
- [Renew](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-renew.html)
- [Cancel](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-assets-cancel.html)
- [Place Sales Transaction](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-place-sales-transaction.html)
- [Asset usage details](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-asset-usage-details.html)
