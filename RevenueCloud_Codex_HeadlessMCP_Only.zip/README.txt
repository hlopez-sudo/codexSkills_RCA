Headless360Only Skills — November 12, 2026

Includes the live Quote, Managing Asset Lifecycle and Managing Revenue Conversion
skills, with their references, API mappings, dependency metadata and helper scripts.

Extract this ZIP and copy the three skill directories into your Codex skills
location (the source installation uses ~/.agents/skills/). Preserve the internal
directory structure. Replacing an existing directory updates that skill.
Connect/authenticate Salesforce Headless MCP in the destination environment.

The mapped Salesforce transaction and lifecycle actions use Headless direct APIs.
The Quote skill retains its existing verified local REST fallback for proposal
PDF generation/download; this export does not change that behavior.

MANIFEST.json records SHA-256 hashes of the exact live files exported.
Python bytecode and caches are excluded. No credentials or runtime sessions are
included. Live-test evidence and documentation-only routes remain distinguished
in each skill's validation and API-mapping references.
