# Headless API mapping and recovery

Use for maintenance, missing source context, split/partial orders or actual errors. Basic conversion and activation are self-contained in [SKILL.md](../SKILL.md).

## Direct execution and maintained routes

Dispatch known mapped paths directly through Headless. A discovery miss is not proof that dispatch is unavailable. Consult canonical documentation or perform targeted discovery/description for unfamiliar operations or actual schema/version errors; do not substitute unrelated Commerce workflows. No revCloud MCP dependency is required.

Paths below are relative to `/services/data/v68.0`. GET uses `dispatch_readonly`; writes use `dispatch`, with `userType: business`. Pass query parameters separately. The connector authenticates; do not set Authorization. Assign the REST body directly to `dispatch.body` without an additional body wrapper. Former tool names are maintenance labels, not execution instructions.

| Action / former tool | Method and path | Request | Success / evidence |
|---|---|---|---|
| Reads / soqlQuery | GET `/query` | `queryParams: {q: "<SOQL>"}` | HTTP 200, `body.records`; complete top-level/child pagination. v68.0 live-tested November 12, 2026. |
| Convert / createOrdersFromQuote | POST `/actions/standard/createOrdersFromQuote` | `{"inputs":[{"quoteId":"<quote ID>"}]}` | HTTP 200, each `body[]` result has isSuccess true, no errors and outputValues.orderIds. Live-tested November 12. |
| Activate / activateOrder | PATCH `/sobjects/Order/{orderId}` | `{"Status":"Activated"}` only | HTTP 204 empty body; verify Status/ActivatedDate once. Live-tested November 12. |
| Reprice / repriceSalesTransaction | POST `/connect/rev/sales-transaction/actions/place` | Existing Quote/Order header PATCH, pricingPref Force; example below | HTTP 201, isSuccess true, empty errorResponse, salesTransactionId; verify completed calculation. Documented; standalone reprice not tested in this run. |
| Provision / orderToAsset | POST `/actions/standard/createOrUpdateAssetFromOrder` | `{"inputs":[{"orderId":"<activated order ID>"}]}` | HTTP success, each `body[]` isSuccess true, no errors, outputValues.requestId. Acceptance is not completion. Documented; not tested in this run. |
| Quote-line usage detail | GET `/commerce/quotes/line-items/{quoteLineItemId}/usage-details` | Optional effectiveDate / optionalFields in queryParams | HTTP 200 with line details; inspect errors. Documented; not newly tested. |
| Order-line usage detail | GET `/commerce/sales-orders/line-items/{orderItemId}/usage-details` | Optional effectiveDate / optionalFields in queryParams | HTTP 200 with line details; inspect errors. Documented; not newly tested. |

The standard-action bodies use `inputs` arrays with string IDs. Do not substitute the old MCP adapter's object-shaped IDs. Standard conversion uses quoteId, not the separate singular createOrderFromQuote action's quoteRecordId. Update path/version, payload, success/async handling, source and evidence together when maintaining mappings.

## Focused source queries

Use `GET /services/data/v68.0/query` with escaped literal values in `queryParams.q`; no Apex bind variables and no manual URL-encoding of q before passing it to the connector.

If the intended quote has not just been verified:

```sql
SELECT Id,QuoteNumber,QuoteAccountId,Status,CalculationStatus,
  CurrencyIsoCode,GrandTotal,BillToContactId,
  (SELECT Id,Product2Id,Quantity,SubscriptionTerm,StartDate,EndDate,
    NetUnitPrice,NetTotalPrice FROM QuoteLineItems)
FROM Quote WHERE Id='<quote ID>'
```

When conversion state is unknown:

```sql
SELECT Id,OrderNumber,Status,QuoteId
FROM Order WHERE QuoteId='<quote ID>'
```

Run these independently when both are needed. Skip duplicate checks for a newly created quote with no conversion attempt. Reuse an existing completed conversion; inspect source-line coverage for separately requested additional partial orders. An ambiguous previous attempt requires a persisted-state check.

Reuse verified fields, record mappings and connection context. No routine identity, metadata or feature-toggle preflight. After reconnecting or changing org, confirm the intended target in that connection before writing. Resolve missing BillTo through an authorized quote edit; do not convert first and repair the order as a substitute.

## Responses and actual async work

Check MCP isError and plain-text errors. Prefer structuredContent, otherwise parse JSON text. Headless returns `{status_code, body, url}`. Check HTTP success and the endpoint-specific business result. Conversion/provisioning results are arrays in body; inspect every result and retain all returned IDs. Save mutation results before parsing so a client wrapper error cannot trigger duplicate creation.

Activation is different: HTTP 204 has an empty body, no isSuccess and no defaultExc wrapper to decode. Confirm the persisted state after the PATCH. If the request failed, inspect its actual error and current order; do not resubmit a successful activation.

Default CreateSingleOrder creates headers and lines synchronously. In the live test requestId and statusUrl were null. Do not insert a sleep or tracker poll. A request ID alone is not proof of pending work. If quote calculation is pending, poll only its state; CompletedWithPricing and CompletedWithTax are completed, while a terminal failure needs error handling.

For explicitly requested CreateOrderByGroup or CreateOrderByField, use the documented orderCreationMethod/orderCreationParameters and quoteLineItemIds when selecting lines. Headers are synchronous and lines asynchronous. Preserve all order IDs, follow returned requestId and statusUrl/statusURL for actual pending work, and verify selected source-line coverage before activation. Do not invent tracker URLs.

Use modest bounded backoff for pending work, normally up to two minutes. Report remaining pending state rather than resubmitting. Compare partial/split orders against their selected source lines rather than the full quote total.

## Conditional repricing and recovery

After timeout, business error or partial create, inspect returned IDs and persisted source-linked orders before retrying; resume only missing work. On INVALID_OPERATION, inspect the actual reason and pricing state. Wait for an existing calculation rather than repricing it. Do not treat every INVALID_OPERATION as a pricing problem.

Only when repricing is needed and authorized, dispatch the mapped Place API with the existing transaction header. This example reprices a Quote; use Order and the actual order ID only for an authorized order reprice:

```json
{
  "pricingPref": "Force",
  "taxPref": "Skip",
  "catalogRatesPref": "Skip",
  "configurationPref": {"configurationMethod": "Skip"},
  "graph": {
    "graphId": "repriceExistingTransaction",
    "records": [{
      "referenceId": "header",
      "record": {
        "attributes": {"type": "Quote", "method": "PATCH", "id": "<quote ID>"}
      }
    }]
  }
}
```

Verify HTTP/business success and completed pricing. Then retry conversion at most once, after confirming the prior attempt created no orders. Do not routinely reprice orders created from quotes: Salesforce documents that carried header adjustments can be reapplied and over-discount the order. Do not reprice after a successful edit already priced its changes.

Activation must PATCH only Status. Resolve actual prerequisite errors through the appropriate authorized edit before retrying; do not combine contact/address/date repairs with activation or bypass business validation. Do not use the older `/connect/revenue-management/orders/actions/activate` example: the repo records NOT_FOUND there, while the Status PATCH passed this org's test.

Authentication failures need supported reauthentication, not repeated discovery, credential extraction or another transport. New quote creation stays with the Quote skill's Place route and billing defaults. Provisioning follows [verification](verification.md) only when requested.

## Evidence and sources

November 12, 2026: direct conversion of amended Quote 00000105 created Draft Order 00000144, preserved two lines' quantities/dates/BillTo and currency Commit grants of USD 600,000 / 1,100,000, then a Status-only PATCH returned 204. One read confirmed Activated and ActivatedDate. No standalone reprice or discovery was needed. [Validation](validation.md) records timings and limits; project evidence is `headless-migration-test-2026-11-12/direct-dispatch-results.json`.

- [Create Orders From Quote](https://developer.salesforce.com/docs/revenue/revenue-management/guide/actions-obj-create-orders-from-quote.html): payload, outputs and sync/async behavior.
- [Order](https://developer.salesforce.com/docs/platform/object-reference/references/standard-objects/object-order.html): activation changes only Status.
- [Place Sales Transaction](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-place-sales-transaction.html): update graph and pricing.
- [Create or Update Asset From Order](https://developer.salesforce.com/docs/revenue/revenue-management/guide/actions-obj-create-update-asset-from-order.html): provisioning body and requestId.
- Repo `postman/docs/usage-management-apis-reference.md`: quote/order-line usage-detail routes.
- Repo `scripts/txn_data_harness/docs/contracts-sales-txn-quote.md`: observed activation PATCH behavior. Release-264 developer-guide snapshots and transaction-management reference support the remaining mappings.
