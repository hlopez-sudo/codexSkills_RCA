# Quote API mapping

Maintenance and optional routing reference. Basic creation is self-contained in [SKILL.md](../SKILL.md); do not load this as an extra creation preflight.

Use known mapped paths directly through Headless. A discovery miss does not invalidate a documented route. For an unfamiliar operation or actual schema/version error, consult its canonical contract and perform targeted discovery/description only if useful. Do not cycle through unrelated Commerce recipes.

## Maintained routes

Paths are relative to `/services/data/v68.0`. GET uses `dispatch_readonly`; writes use `dispatch`, with `userType: business`. Supply `queryParams` separately and let the connector authenticate. Request bodies below are assigned to `dispatch.body` without an extra nested `body` object.

| Action / former tool equivalent | Method and path | Request | Success / evidence |
|---|---|---|---|
| Reads / soqlQuery | GET `/query` | `queryParams: {q: "<SOQL>"}` | HTTP 200, `body.records`; complete top-level and child pagination. v68.0 live-tested November 12, 2026. |
| Create quote / createSalesTransaction, addLines | POST `/connect/rev/sales-transaction/actions/place` | Quote POST then line POST records; billing, BillTo and pricing preferences from SKILL.md | HTTP 201, `body.isSuccess`, empty `errorResponse`, `salesTransactionId`. Creation tested October 22, not repeated November 12. |
| Quantity, discount, add/remove / updateLines | POST `/connect/rev/sales-transaction/actions/place` | Parent Quote PATCH plus requested line PATCH/POST/DELETE records | Same Place result. [Edit procedure](usage-negotiation.md) defines preferences/targets. |
| Commitment/allowance/rate edits | POST `/connect/rev/sales-transaction/actions/place` | Parent Quote PATCH plus existing grant/rate/adjustment PATCH records; System pricing and catalog Skip | Combined amendment quantities and currency Commit grants live-tested November 12. Other coverage is in [validation](validation.md). |
| Line usage details | GET `/commerce/quotes/line-items/{quoteLineItemId}/usage-details` | Optional `effectiveDate` / `optionalFields` in queryParams | HTTP 200 with usage details; inspect errors. Not newly tested November 12. |
| Anchor catalog rates | GET `/query` | Scoped RateCardEntry SOQL from [usage reading](usage-reading.md) | Match resource, unit, currency, selling model and effective date. |

The Quote skill already used Headless; former-tool labels identify equivalents, not previous dependencies. Proposal generation/download retains [document output](document-output.md) and its verified same-org/user local REST fallback. This migration does not establish MCP-only document support.

## Responses and retries

Prefer `structuredContent`, otherwise parse JSON text after checking MCP errors. Headless returns `status_code`, `body` and `url`. Check HTTP and business success. Store raw mutation results and IDs before parsing so a wrapper error does not cause duplicate creation.

A saved header can survive a later Place failure. After an ambiguous write, read persisted state and repair only missing work. Follow actual pending processing, not a request identifier alone. CompletedWithPricing and CompletedWithTax are completed states. Do not add a separate reprice after Place already priced the changes.

## Evidence and maintenance

November 12, 2026: v68.0 queries and one Place graph changed two amendment lines by +250 and currency Commit grants to USD 600,000 / 1,100,000. Exact values and all 16 untouched allowance grants were verified. Conversion preserved the commitments on Order 00000144. No discovery was needed in the successful sequence. This does not retest new-sale creation, every rate edit or proposal generation.

When changing a mapping, update method/path/version, request, success/async handling, source and evidence together. Keep documented and live-tested coverage distinct. See [validation](validation.md).

Sources: repo `postman/docs/transaction-management-apis-reference.md`, `postman/docs/usage-management-apis-reference.md`, release-264 Place input/output snapshots, and project `headless-migration-test-2026-11-12/direct-dispatch-results.json`.

- [Place Sales Transaction](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-place-sales-transaction.html)
- [Quote Line Item Usage Details](https://developer.salesforce.com/docs/revenue/revenue-management/guide/connect-resources-quote-usage-details.html)
